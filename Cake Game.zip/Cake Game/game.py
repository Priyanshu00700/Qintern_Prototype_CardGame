import pygame
import sys
import webbrowser
from tell.c1 import run_entangled_cake_and_circuit_game1
from tell.c2 import run_entangled_cake_and_circuit_game2

# ---------- SCREENS ----------

def show_start_screen(screen, font_big):
    background = pygame.image.load("assets/QWorld.png").convert()
    background = pygame.transform.scale(background, screen.get_size())
    screen.blit(background, (0, 0))

    title = font_big.render("Quantum Cake", True, (0, 0, 0))
    start_text = font_big.render("Start", True, (255, 255, 255))
    button_rect = pygame.Rect(350, 300, 200, 60)
    pygame.draw.rect(screen, (70, 130, 180), button_rect, border_radius=10)
    screen.blit(title, (350, 10))
    screen.blit(start_text, (button_rect.x + 68, button_rect.y + 12))

    pygame.display.update()
    return button_rect


def show_level_screen(screen, font_big, unlocked_levels, completed_levels, total_levels=6):
    screen.fill((200, 200, 200))
    title = font_big.render("Select Level", True, (0, 0, 0))
    screen.blit(title, (330, 50))

    buttons = []
    levels_per_row = 3  # first 3 on top, next 3 below
    for i in range(total_levels):
        row = i // levels_per_row
        col = i % levels_per_row

        x = 150 + (col * 200)
        y = 200 + (row * 100)  # 100px gap between rows

        rect = pygame.Rect(x, y, 150, 60)

        if i in completed_levels:
            color = (0, 200, 0)   # green = completed
        elif i in unlocked_levels:
            color = (255, 255, 255) # white = current level
        else:
            color = (150, 150, 150) # grey = locked

        pygame.draw.rect(screen, color, rect, border_radius=8)
        pygame.draw.rect(screen, (0, 0, 0), rect, 3, border_radius=8)

        label = font_big.render(f"Level {i+1}", True, (0, 0, 0))
        screen.blit(label, (rect.x + 20, rect.y + 10))

        buttons.append(rect)

    pygame.display.update()
    return buttons


def show_win_screen(screen, font_big):
    screen.fill((240, 255, 240))
    win_text = font_big.render("You Win!", True, (34, 139, 34))
    screen.blit(win_text, (350, 200))
    prompt = font_big.render("Press any key to exit...", True, (0, 0, 0))
    screen.blit(prompt, (230, 300))
    pygame.display.update()

    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Open feedback before quitting
                webbrowser.open("https://forms.gle/B8VfuofKE9hMcqmc9")
                pygame.quit()
                sys.exit()
            elif event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
                # Open feedback before quitting
                webbrowser.open("https://forms.gle/B8VfuofKE9hMcqmc9")
                waiting = False


# ---------- GAME SEQUENCE ----------
def run_game_sequence(game_functions, win_function, screen, font_big):
    for game_func in game_functions:
        if not game_func():
            return False
    win_function(screen, font_big)
    pygame.quit()
    sys.exit()


# ---------- MAIN ----------
def main():
    pygame.init()
    WIDTH, HEIGHT = 900, 500
    pygame.mixer.music.load("assets/Mi Borinquen - Doug Maxwell_Jimmy Fontanez.mp3")
    pygame.mixer.music.play(-1)
    pygame.mixer.music.set_volume(0.25)

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Quantum Cake Game Launcher")
    font_big = pygame.font.SysFont('Arial', 36)
    clock = pygame.time.Clock()

    completed_levels = set()
    unlocked_levels = {0}  # start with level 1 unlocked

    # --------- START SCREEN LOOP ---------
    while True:
        start_button = show_start_screen(screen, font_big)
        waiting = True
        while waiting:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    webbrowser.open("https://forms.gle/B8VfuofKE9hMcqmc9")
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if start_button.collidepoint(event.pos):
                        waiting = False
            clock.tick(60)

        # --------- LEVEL SCREEN LOOP ---------
        level_waiting = True
        while level_waiting:
            level_buttons = show_level_screen(screen, font_big, unlocked_levels, completed_levels)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    webbrowser.open("https://forms.gle/B8VfuofKE9hMcqmc9")
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    for i, rect in enumerate(level_buttons):
                        if rect.collidepoint(event.pos) and i in unlocked_levels:
                            # Run that level
                            if i == 0:
                                result = run_entangled_cake_and_circuit_game1(0)
                            elif i == 1:
                                result = run_entangled_cake_and_circuit_game1(1)
                            elif i == 2:
                                result = run_entangled_cake_and_circuit_game1(2)
                            elif i == 3:
                                result = run_entangled_cake_and_circuit_game2(0)
                            elif i == 4:
                                result = run_entangled_cake_and_circuit_game2(1)
                            elif i == 5:
                                result = run_entangled_cake_and_circuit_game2(2)

                            if result:
                                completed_levels.add(i)
                                unlocked_levels.add(i + 1)
                                if len(completed_levels) == 6:
                                    show_win_screen(screen, font_big)
                                    webbrowser.open("https://your-feedback-form-link.com")
                                    pygame.quit()
                                    sys.exit()
            clock.tick(60)


if __name__ == "__main__":
    main()
