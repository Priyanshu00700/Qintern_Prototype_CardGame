if __name__ == "__main__":
    run_entangled_cake_and_circuit_game()