from setuptools import setup, find_packages

setup(
    name="project_cake_game",
    version="1.0.0",
    description="A quantum cake-themed game using Pygame and Cirq",
    author="Your Name",
    packages=find_packages(),
    install_requires=[
        "pygame>=2.0.0",
        "cirq>=1.0.0",
    ],
    entry_points={
        "console_scripts": [
            "cakegame=project_cake_game.main:main",  
            # Replace 'project_cake_game.main:main' with your actual module and function
        ],
    },
    python_requires='>=3.7',
)
