import pygame
import sys
from tell.c1 import run_entangled_cake_and_circuit_game1  # Your main game function
from tell.c2 import run_entangled_cake_and_circuit_game2  # Your main game function




def show_start_screen(screen, font_big):
    background = pygame.image.load("QWorld.png").convert()
    background = pygame.transform.scale(background, screen.get_size())  # Scales to fit the screen
    screen.blit(background, (0, 0))

    title = font_big.render("Quantum Cake", True, (0, 0, 0))
    start_text = font_big.render("Start", True, (255, 255, 255))
    button_rect = pygame.Rect(350, 300, 200, 60)
    pygame.draw.rect(screen, (70, 130, 180), button_rect, border_radius=10)
    screen.blit(title, (350, 10))
    screen.blit(start_text, (button_rect.x + 68, button_rect.y + 12))

    pygame.display.update()
    return button_rect

def show_win_screen(screen, font_big):
    screen.fill((240, 255, 240))
    win_text = font_big.render("You Win!", True, (34, 139, 34))
    screen.blit(win_text, (350, 200))
    prompt = font_big.render("Press any key to exit...", True, (0, 0, 0))
    screen.blit(prompt, (230, 300))
    pygame.display.update()

    # Wait for any key press
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False


def run_game_sequence(game_functions, win_function, screen, font_big):
    i = 0
    for game_func in game_functions:
        result = game_func()
        if result:
            i+=1
            if i>=len(game_functions):
                win_function(screen, font_big)
                pygame.quit()
                sys.exit()
            
    return False  

def main():
    pygame.init()
    WIDTH, HEIGHT = 900, 500
    pygame.mixer.music.load("Mi Borinquen - Doug Maxwell_Jimmy Fontanez.mp3")
    pygame.mixer.music.play(-1)  
    pygame.mixer.music.set_volume(0.25)
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Quantum Cake Game Launcher")
    font_big = pygame.font.SysFont('Arial', 36)
    clock = pygame.time.Clock()

    while True:
        button_rect = show_start_screen(screen, font_big)

        waiting = True
        while waiting:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = pygame.mouse.get_pos()
                    if button_rect.collidepoint(mx, my):
                        game_list = [run_entangled_cake_and_circuit_game1,run_entangled_cake_and_circuit_game2]

                        waiting = run_game_sequence(game_list, show_win_screen, screen, font_big)
            clock.tick(60)

if __name__ == "__main__":
    main()