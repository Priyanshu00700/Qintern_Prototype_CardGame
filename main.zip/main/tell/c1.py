import pygame
import sys
import math
import cirq

# Game state
i = 0

# --- Quantum Functions ---

def get_flavors(circuit):
    simulator = cirq.Simulator()
    result = simulator.run(circuit, repetitions=1)
    measurements = result.measurements

    def extract(name):
        return measurements.get(name, [[0]])[0][0]

    cakeA = 'chocolate' if extract("cakeA_Base") == 0 else 'orange'
    cakeB = 'mango' if extract("cakeB_Base") == 0 else 'apple'
    frosting = 'vanilla' if extract("Frosting") == 0 else 'strawberry'

    return cakeA, cakeB, frosting

def puzzle_1():
    qubit_names = ["cakeA_Base", "cakeB_Base", "Frosting"]
    qubits = [cirq.NamedQubit(name) for name in qubit_names]
    circuit = cirq.Circuit(
        cirq.H(qubits[0]),
        cirq.CNOT(qubits[0], qubits[1]),
        cirq.X(qubits[2]),
        cirq.measure(qubits[0], key="cakeA_Base"),
        cirq.measure(qubits[1], key="cakeB_Base"),
        cirq.measure(qubits[2], key="Frosting"),
    )
    return circuit

def puzzle_2():
    qubit_names = ["cakeA_Base", "cakeB_Base", "Frosting"]
    qubits = [cirq.NamedQubit(name) for name in qubit_names]
    circuit = cirq.Circuit(
        cirq.X(qubits[0]),
        cirq.H(qubits[1]),
        cirq.CNOT(qubits[1], qubits[0]),
        cirq.H(qubits[2]),
        cirq.measure(qubits[0], key="cakeA_Base"),
        cirq.measure(qubits[1], key="cakeB_Base"),
        cirq.measure(qubits[2], key="Frosting"),
    )
    return circuit

def puzzle_1_Data():
    return (
        "Cake A :: Base Flavor--\n|0>=Chocolate, |1>= Orange\n"
        "Cake B :: Base Flavor--\n|0>=Mango,     |1>= Apple\n"
        "Frosting :: Flavor--\n|0>=Vanilla,   |1>= Strawberry"
    )

def puzzle_2_Data():
    return (
        "Cake A :: Base Flavor--\n|0>=Chocolate, |1>= Orange\n"
        "Cake B :: Base Flavor--\n|0>=Mango,     |1>= Apple\n"
        "Frosting :: Flavor--\n|0>=Vanilla,   |1>= Strawberry"
    )

# --- Dialogue Box Function ---
def draw_dialogue_box(screen, message, width, height, font):
    box_height = 180
    padding = 15
    box_width = int(width * 0.75)  # 75% of screen width
    box_x = 0  # Start from the left
    box_rect = pygame.Rect(box_x, height - box_height, box_width, box_height)

    pygame.draw.rect(screen, (30, 30, 30), box_rect)  # Dark background
    pygame.draw.rect(screen, (200, 200, 200), box_rect, 2)  # Light border

    # Wrap text within 75% of screen width
    words = message.split(' ')
    lines = []
    line = ''
    for word in words:
        test_line = line + word + ' '
        if font.size(test_line)[0] < box_width - 2 * padding:
            line = test_line
        else:
            lines.append(line)
            line = word + ' '
    lines.append(line)

    for i, line in enumerate(lines[:6]):  
        text_surface = font.render(line.strip(), True, (255, 255, 255))
        screen.blit(text_surface, (box_x + padding, height - box_height + padding + i * 25))

# --- notification screen ---
def show_level_complete_screen(screen, width, height):
    violet = (255, 255, 255)      # Violet background
    purple_ink = (12, 0, 128)  # Purple text

    screen.fill(violet)

    font_big = pygame.font.SysFont('Arial', 48, bold=True)
    font_small = pygame.font.SysFont('Arial', 28)

    text1 = font_big.render("Level Complete!", True, purple_ink)
    text2 = font_small.render("Get ready for the next level...", True, purple_ink)

    screen.blit(text1, text1.get_rect(center=(width // 2, height // 2 - 40)))
    screen.blit(text2, text2.get_rect(center=(width // 2, height // 2 + 20)))

    pygame.display.update()
    pygame.time.wait(1250)

# --- Main Game Function ---

def run_entangled_cake_and_circuit_game1():
    global i

    pygame.init()

    # Load level
    puzzles = [puzzle_1, puzzle_2]
    puzzle_data = [puzzle_1_Data, puzzle_2_Data]
    puzzle_hints = [
        "~ Hint 1: Here an Entangled Bell State is formed betweeen Base Flavor of both Cake . This results in |ab>= 1/√2(|00 > + |11 >) here, a represent Cake A, b represent Cake B.   ~ Hint 2: Use circuit for the cake to determine flavors for the cake",
        "Hint: This time the entanglement goes the other way. See the circuit carefully!"
    ]

    if i >= len(puzzles):
        print("All levels completed!")
        pygame.quit()
        return

    flavor_tuple = get_flavors(puzzles[i]())

    WIDTH, HEIGHT = 900, 500
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Entangled Cake & Circuit Viewer")

    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)
    GREY = (220, 220, 220)
    BLUE = (70, 130, 180)
    RED = (255,0,0)

    font = pygame.font.SysFont('Courier New', 24)
    font_big = pygame.font.SysFont('Arial', 32)

    flavor_colors = {
        'chocolate': (210, 180, 140),
        'orange': (255, 165, 0),
        'mango': (255, 204, 0),
        'apple': (144, 238, 144),
        'vanilla': (255, 255, 240),
        'strawberry': (255, 182, 193)
    }
    flavor_keys = list(flavor_colors.keys())

    class Cake:
        def __init__(self, x, y, width, layer_height, layers=3):
            self.x = x
            self.y = y
            self.width = width
            self.layer_height = layer_height
            self.layers = layers
            self.base_color = BLACK
            self.cream_added = False
            self.cream_color = BLACK
            self.visible = False

        def draw(self, screen):
            if not self.visible:
                return
            for i in range(self.layers):
                rect = pygame.Rect(self.x, self.y + i * self.layer_height, self.width, self.layer_height)
                pygame.draw.rect(screen, self.base_color, rect)
            if self.cream_added:
                top_y = self.y
                points = [(self.x, top_y), (self.x + self.width, top_y)]
                for x in range(self.x + self.width, self.x - 1, -6):
                    y = top_y + 10 + 6 * math.sin((x - self.x) / 15)
                    points.append((x, y))
                points.append((self.x, top_y))
                pygame.draw.polygon(screen, self.cream_color, points)

    cakeA = Cake(x=100, y=200, width=150, layer_height=35)
    cakeA.visible = True
    cakeB = Cake(x=400, y=200, width=150, layer_height=35)
    cakeB.base_color = flavor_colors[flavor_tuple[1]]
    cakeB.cream_color = flavor_colors[flavor_tuple[2]]
    cakeB.cream_added = True
    cakeB.visible = False

    result_text = ""
    dropdowns = {"base_open": False, "cream_open": False}
    selected_base = "vanilla"
    selected_cream = "vanilla"
    current_view = "cake"
    hint_visible = False  # ← Controls hint visibility

    # Buttons
    button_width, button_height = 180, 50
    view_toggle_button = pygame.Rect(WIDTH - button_width - 20, HEIGHT - button_height - 20, button_width, button_height)
    hint_button = pygame.Rect(WIDTH - 125, 25, 100, 35)

    def render_text_block(text, x, y, line_height=30):
        lines = text.splitlines()
        for i, line in enumerate(lines):
            rendered_line = font.render(line, True, BLUE)
            screen.blit(rendered_line, (x, y + i * line_height))

    running = True
    while running:
        screen.fill(WHITE)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()

                if view_toggle_button.collidepoint(mx, my):
                    current_view = "circuit" if current_view == "cake" else "cake"

                if current_view == "cake":
                    if hint_button.collidepoint(mx, my):
                        hint_visible = not hint_visible

                    if pygame.Rect(50, 50, 100, 40).collidepoint(mx, my):
                        cakeB.visible = True
                    elif pygame.Rect(170, 50, 100, 40).collidepoint(mx, my):
                        expected_base = flavor_tuple[0]
                        expected_cream = flavor_tuple[2]
                        result_text = "Matched!" if selected_base == expected_base and selected_cream == expected_cream else "Not matched"
                        if result_text == "Matched!":
                            show_level_complete_screen(screen,WIDTH,HEIGHT)
                            i += 1
                            if i < 2:
                                run_entangled_cake_and_circuit_game1()
                            return True
                        else:
                            return False
                    elif pygame.Rect(160, 115, 120, 30).collidepoint(mx, my):
                        dropdowns["base_open"] = not dropdowns["base_open"]
                        dropdowns["cream_open"] = False
                    elif pygame.Rect(420, 115, 120, 30).collidepoint(mx, my):
                        dropdowns["cream_open"] = not dropdowns["cream_open"]
                        dropdowns["base_open"] = False
                    elif dropdowns["base_open"]:
                        for j, flavor in enumerate(flavor_keys):
                            option_rect = pygame.Rect(160, 145 + j * 30, 120, 30)
                            if option_rect.collidepoint(mx, my):
                                selected_base = flavor
                                cakeA.base_color = flavor_colors[flavor]
                                dropdowns["base_open"] = False
                                break
                    elif dropdowns["cream_open"]:
                        for j, flavor in enumerate(flavor_keys):
                            option_rect = pygame.Rect(420, 145 + j * 30, 120, 30)
                            if option_rect.collidepoint(mx, my):
                                selected_cream = flavor
                                cakeA.cream_color = flavor_colors[flavor]
                                cakeA.cream_added = True
                                dropdowns["cream_open"] = False
                                break

        if current_view == "cake":
            cakeA.draw(screen)
            cakeB.draw(screen)
            screen.blit(font.render("Cake A", True, BLACK), (140, 180))
            screen.blit(font.render("Cake B", True, BLACK), (440, 180))
            pygame.draw.rect(screen, WHITE, (50, 50, 100, 40), border_radius=5)
            pygame.draw.rect(screen, BLACK, (50, 50, 100, 40), 2)
            screen.blit(font.render("Reveal", True, BLACK), (60, 60))
            pygame.draw.rect(screen, WHITE, (170, 50, 100, 40), border_radius=5)
            pygame.draw.rect(screen, BLACK, (170, 50, 100, 40), 2)
            screen.blit(font.render("Check", True, BLACK), (180, 60))
            screen.blit(font.render("Flavor:", True, BLACK), (50, 120))
            base_dropdown_rect = pygame.Rect(160, 115, 145, 30)
            pygame.draw.rect(screen, GREY, base_dropdown_rect)
            pygame.draw.rect(screen, BLACK, base_dropdown_rect, 1)
            screen.blit(font.render(selected_base, True, BLACK), (165, 120))
            if dropdowns["base_open"]:
                for j, flavor in enumerate(flavor_keys):
                    option_rect = pygame.Rect(160, 145 + j * 30, 145, 30)
                    pygame.draw.rect(screen, flavor_colors[flavor], option_rect)
                    pygame.draw.rect(screen, BLACK, option_rect, 1)
                    screen.blit(font.render(flavor, True, BLACK), (165, 150 + j * 30))
            screen.blit(font.render("Frosting:", True, BLACK), (310, 120))
            cream_dropdown_rect = pygame.Rect(450, 115, 145, 30)
            pygame.draw.rect(screen, GREY, cream_dropdown_rect)
            pygame.draw.rect(screen, BLACK, cream_dropdown_rect, 1)
            screen.blit(font.render(selected_cream, True, BLACK), (455, 120))
            if dropdowns["cream_open"]:
                for j, flavor in enumerate(flavor_keys):
                    option_rect = pygame.Rect(450, 145 + j * 30, 145, 30)
                    pygame.draw.rect(screen, flavor_colors[flavor], option_rect)
                    pygame.draw.rect(screen, BLACK, option_rect, 1)
                    screen.blit(font.render(flavor, True, BLACK), (455, 150 + j * 30))
            screen.blit(font.render(result_text, True, (0, 0, 255)), (50, 90))

            # Hint toggle button
            pygame.draw.rect(screen, WHITE, hint_button, border_radius=6)

            pygame.draw.rect(screen, BLUE, hint_button, width=2, border_radius=6)

            hint_label = font.render("HINT", True, BLUE)
            screen.blit(hint_label, (hint_button.x + 25, hint_button.y + 5))

            # Hint box
            if hint_visible:
                draw_dialogue_box(screen, puzzle_hints[i], WIDTH, HEIGHT, font)

        elif current_view == "circuit":
            render_text_block(str(puzzles[i]()), 50, 50)
            render_text_block(puzzle_data[i](), 50, 220)
            tip_text = font.render("Click 'Go to Cake' to return.", True, (100, 100, 100))
            screen.blit(tip_text, (50, HEIGHT - 40))

        pygame.draw.rect(screen, BLUE, view_toggle_button, border_radius=10)
        button_label = "Go to Circuit" if current_view == "cake" else "Go to Cake"
        text_surface = font_big.render(button_label, True, WHITE)
        text_rect = text_surface.get_rect(center=view_toggle_button.center)
        screen.blit(text_surface, text_rect)

        pygame.display.update()
